
// while (true) {
//     let a = 1 * 1;
//     let b = a * 100
//     console.log(b)
// }
// let password = "";

// do {
//   password = prompt("Введи пароль більше 5 символів");
// } while (password.length > 5);

// console.log(password);